
public class CheckPalindrome {
	  static boolean isPalindrome(int n) 
	    {     
	        int divisor = 1; 
	        while (n / divisor >= 10) 
	            divisor *= 10; 
	       
	        while (n != 0) 
	        { 
	            int leading = n / divisor;  
	            int trailing = n % 10; 
	       
	            if (leading != trailing)   
	                return false; 
	            n = (n % divisor) / 10; 
	       
	            divisor = divisor / 100; 
	        } 
	        return true;
	    }
	public static void main(String[] args) {
		 if(isPalindrome(100111)) 
	            System.out.println("Palindrome"); 
	        else
	            System.out.println(" Not Palindrome"); 

	}

}

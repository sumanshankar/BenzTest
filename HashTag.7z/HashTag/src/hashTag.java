import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class hashTag {

	public static void main(String[] args) {
		String str = "How the Avocado Became the Fruit of the Global Trade";
		int move = 0;
		ArrayList<String> newList = new ArrayList<>();
		MyComparator mc = new MyComparator();
		String array[] = str.split(" ");
		List<String> list = Arrays.asList(array);
		Collections.sort(list,mc);
		int lenght = list.size();
		if (lenght<=2) {
			move = lenght;
		for(int i =0 ; i<move ;i++)
		{
			newList.add("#"+list.get(i).toLowerCase());
			
		}
		}
		
		else move = 3;
		for(int i =0 ; i<move ;i++)
		{
			newList.add("#"+list.get(i).toLowerCase());
			
		}
		System.out.println(newList);
	}

}

class MyComparator implements java.util.Comparator<String> {

    public int compare(String s1, String s2) {
    	
    	int dist1 = s1.length();
    	int dist2 = s2.length();
        return dist2 - dist1;
    }
}